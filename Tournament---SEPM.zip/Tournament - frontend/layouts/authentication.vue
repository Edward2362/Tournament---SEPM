<template>
  <nuxt />
</template>

<script>

export default {
  components: {
  },
};
</script>
