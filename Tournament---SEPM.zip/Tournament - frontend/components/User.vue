<template>
  <div id="profile">
    <img htmlFor="profile" src="../assets/images/Quang.jpg" />
  </div>
</template>

<script>
export default {
  name: "User",
};
</script>

<style scoped>
@import "../assets/styles/user.css";
</style>
