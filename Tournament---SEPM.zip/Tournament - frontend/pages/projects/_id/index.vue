<template>
  <div class="project-content">
    <h2 class="section-head">Ranking</h2>
    <div class="section-body"></div>
  </div>
</template>

<script>
export default {
  components: {},
  layout: "project",
};
</script>

<style>
@import "../../../assets/styles/dashboard.css";
</style>
