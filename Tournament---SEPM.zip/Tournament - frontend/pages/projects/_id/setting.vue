<template>
  <div class="project-content">
    <h2 class="section-head">Setting</h2>
  </div>
</template>

<script>
export default {
  components: {},
  layout: "project",
};
</script>

<style></style>
